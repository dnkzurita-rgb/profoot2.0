import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'src/app/app_shell.dart';
import 'src/features/profile/data/player_profile_model.dart';
import 'src/features/scouting/presentation/player_scouting_screen.dart';
import 'src/features/telemetry/data/shot_telemetry_model.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(PlayerProfileAdapter());
  Hive.registerAdapter(ShotTelemetryAdapter());
  await Hive.openBox<PlayerProfile>(PlayerScoutingScreen.boxName);
  await Hive.openBox<ShotTelemetry>('shot_box');
  runApp(const ProFootApp());
}
