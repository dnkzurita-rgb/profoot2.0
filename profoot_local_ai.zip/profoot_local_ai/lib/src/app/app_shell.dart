import 'package:flutter/material.dart';

import '../features/ai_trainer/presentation/ai_trainer_camera_view.dart';
import '../features/scouting/presentation/player_scouting_screen.dart';

class ProFootApp extends StatelessWidget {
  const ProFootApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ProFoot Local AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        brightness: Brightness.dark,
      ),
      home: const _Shell(),
    );
  }
}

class _Shell extends StatefulWidget {
  const _Shell();
  @override
  State<_Shell> createState() => _ShellState();
}

class _ShellState extends State<_Shell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        top: _index != 0,
        child: IndexedStack(
          index: _index,
          children: [
            // Camera view is only built when selected to release the camera otherwise.
            _index == 0 ? const AiTrainerCameraView() : const SizedBox.shrink(),
            const PlayerScoutingScreen(),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.videocam_outlined), label: 'AI Coach'),
          NavigationDestination(
              icon: Icon(Icons.badge_outlined), label: 'Scouting'),
        ],
      ),
    );
  }
}
