import 'package:hive/hive.dart';

/// One measured shot, persisted locally in Hive (typeId 1).
class ShotTelemetry {
  const ShotTelemetry({
    required this.id,
    required this.timestamp,
    required this.velocityKmh,
    required this.distanceMeters,
    required this.flightTimeSeconds,
    required this.goalZone,
    required this.weakFoot,
  });

  final String id;
  final DateTime timestamp;
  final double velocityKmh;
  final double distanceMeters;
  final double flightTimeSeconds;

  /// 0..8, row-major: 0 = top-left ... 8 = bottom-right. -1 = missed the frame.
  final int goalZone;
  final bool weakFoot;
}

class ShotTelemetryAdapter extends TypeAdapter<ShotTelemetry> {
  @override
  final int typeId = 1;

  @override
  ShotTelemetry read(BinaryReader reader) {
    final n = reader.readByte();
    final fields = <int, dynamic>{
      for (var i = 0; i < n; i++) reader.readByte(): reader.read(),
    };
    return ShotTelemetry(
      id: fields[0] as String,
      timestamp: DateTime.fromMillisecondsSinceEpoch(fields[1] as int),
      velocityKmh: fields[2] as double,
      distanceMeters: fields[3] as double,
      flightTimeSeconds: fields[4] as double,
      goalZone: fields[5] as int,
      weakFoot: fields[6] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, ShotTelemetry obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.timestamp.millisecondsSinceEpoch)
      ..writeByte(2)
      ..write(obj.velocityKmh)
      ..writeByte(3)
      ..write(obj.distanceMeters)
      ..writeByte(4)
      ..write(obj.flightTimeSeconds)
      ..writeByte(5)
      ..write(obj.goalZone)
      ..writeByte(6)
      ..write(obj.weakFoot);
  }
}
