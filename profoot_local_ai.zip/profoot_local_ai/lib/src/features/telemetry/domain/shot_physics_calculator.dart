import 'dart:math' as math;

/// Result of a shot computation.
class ShotResult {
  const ShotResult({
    required this.velocityKmh,
    required this.flightTimeSeconds,
    required this.launchAngleDegrees,
    required this.zone,
  });
  final double velocityKmh;
  final double flightTimeSeconds;
  final double launchAngleDegrees;

  /// 0..8 (row-major, 0 = top-left) or -1 if outside the goal.
  final int zone;
}

class ShotPhysicsCalculator {
  ShotPhysicsCalculator._();

  static const double gravity = 9.81;
  static const double goalWidthM = 7.32;
  static const double goalHeightM = 2.44;
  static const double ballRestHeightM = 0.11;

  /// Time of flight from frame indices at the camera's measured FPS.
  static double flightTime({
    required int impactFrame,
    required int goalContactFrame,
    required double fps,
  }) {
    if (fps <= 0 || goalContactFrame <= impactFrame) return 0;
    return (goalContactFrame - impactFrame) / fps;
  }

  /// Estimates initial ball speed (km/h) from a ballistic trajectory.
  ///
  /// Horizontal speed vx = distance / t. Vertical launch speed solves
  /// y(t) = y0 + vy*t - g*t^2/2  =>  vy = (y - y0 + g*t^2/2) / t.
  /// Launch speed = sqrt(vx^2 + vy^2); drag is neglected, so the estimate is
  /// slightly conservative.
  static ShotResult compute({
    required double distanceMeters,
    required double flightTimeSeconds,
    required double goalImpactXMeters, // 0..7.32 from the left post
    required double goalImpactYMeters, // height above ground at the goal line
  }) {
    if (flightTimeSeconds <= 0 || distanceMeters <= 0) {
      return const ShotResult(
          velocityKmh: 0, flightTimeSeconds: 0, launchAngleDegrees: 0, zone: -1);
    }
    final t = flightTimeSeconds;
    final vx = distanceMeters / t;
    final vy =
        (goalImpactYMeters - ballRestHeightM + 0.5 * gravity * t * t) / t;
    final v0 = math.sqrt(vx * vx + vy * vy);
    final angle = math.atan2(vy, vx) * 180 / math.pi;
    return ShotResult(
      velocityKmh: v0 * 3.6,
      flightTimeSeconds: t,
      launchAngleDegrees: angle,
      zone: goalZone(goalImpactXMeters, goalImpactYMeters),
    );
  }

  /// 9-zone matrix: columns = left/center/right, rows = top/middle/bottom.
  /// Index = row * 3 + col, so 0 = top-left and 8 = bottom-right.
  static int goalZone(double xMeters, double yMeters) {
    if (xMeters < 0 ||
        xMeters > goalWidthM ||
        yMeters < 0 ||
        yMeters > goalHeightM) {
      return -1;
    }
    final col = math.min(2, (xMeters / (goalWidthM / 3)).floor());
    final rowFromBottom = math.min(2, (yMeters / (goalHeightM / 3)).floor());
    final row = 2 - rowFromBottom;
    return row * 3 + col;
  }

  /// Precision score (0..100) for a zone: corners are hardest to save.
  static double zonePrecisionScore(int zone) {
    const scores = [100.0, 70.0, 100.0, 55.0, 30.0, 55.0, 90.0, 60.0, 90.0];
    if (zone < 0 || zone > 8) return 0;
    return scores[zone];
  }
}
