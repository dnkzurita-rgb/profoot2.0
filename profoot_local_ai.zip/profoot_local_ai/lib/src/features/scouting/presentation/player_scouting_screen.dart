import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../profile/data/player_profile_model.dart';
import '../domain/scouting_calculator.dart';

class PlayerScoutingScreen extends StatelessWidget {
  const PlayerScoutingScreen({super.key});

  static const String boxName = 'profile_box';
  static const String profileKey = 'me';

  static PlayerProfile _defaultProfile() =>
      PlayerProfile(id: profileKey, name: 'YOUR NAME');

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Box<PlayerProfile>>(
      valueListenable: Hive.box<PlayerProfile>(boxName).listenable(),
      builder: (context, box, _) {
        final profile = box.get(profileKey) ?? _defaultProfile();
        final report = ScoutingCalculator.analyze(profile);
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _PlayerCard(profile: profile, report: report),
            const SizedBox(height: 20),
            _Radar(report: report),
            const SizedBox(height: 20),
            _Recommendation(report: report),
            const SizedBox(height: 20),
            _StatEditor(
              profile: profile,
              onChanged: (p) {
                final r = ScoutingCalculator.analyze(p);
                box.put(
                  profileKey,
                  p.copyWith(positionCompatibility: {
                    for (final e in r.compatibility.entries) e.key.code: e.value
                  }),
                );
              },
            ),
          ],
        );
      },
    );
  }
}

class _PlayerCard extends StatelessWidget {
  const _PlayerCard({required this.profile, required this.report});
  final PlayerProfile profile;
  final ScoutingReport report;

  @override
  Widget build(BuildContext context) {
    final s = report.stats;
    Widget stat(String label, double v) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(children: [
            Text(v.round().toString(),
                style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF3B2A00))),
            const SizedBox(width: 8),
            Text(label,
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF3B2A00))),
          ]),
        );

    return Center(
      child: Container(
        width: 280,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFF6E27A), Color(0xFFD4A937), Color(0xFFF3D77A)],
          ),
          borderRadius: BorderRadius.circular(22),
          boxShadow: const [
            BoxShadow(color: Colors.black38, blurRadius: 16, offset: Offset(0, 8))
          ],
        ),
        child: Column(children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Column(children: [
              Text('${report.overall}',
                  style: const TextStyle(
                      fontSize: 52,
                      height: 1,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF3B2A00))),
              Text(report.bestPosition.code,
                  style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF3B2A00))),
            ]),
            const Spacer(),
            const Icon(Icons.sports_soccer, size: 90, color: Color(0x553B2A00)),
          ]),
          const SizedBox(height: 8),
          Text(profile.name.toUpperCase(),
              style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  color: Color(0xFF3B2A00))),
          const Divider(color: Color(0x663B2A00), thickness: 1.5),
          Row(children: [
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              stat('PAC', s.pace),
              stat('SHO', s.shooting),
            ])),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              stat('PAS', s.passing),
              stat('WF', s.weakFoot),
            ])),
          ]),
        ]),
      ),
    );
  }
}

class _Radar extends StatelessWidget {
  const _Radar({required this.report});
  final ScoutingReport report;

  @override
  Widget build(BuildContext context) {
    final s = report.stats;
    final labels = ['Pace', 'Shooting', 'Passing', 'Weak Foot'];
    final values = [s.pace, s.shooting, s.passing, s.weakFoot];
    final color = Theme.of(context).colorScheme.primary;
    return SizedBox(
      height: 280,
      child: RadarChart(
        RadarChartData(
          dataSets: [
            RadarDataSet(
              fillColor: color.withOpacity(0.3),
              borderColor: color,
              entryRadius: 3,
              borderWidth: 2,
              dataEntries: [for (final v in values) RadarEntry(value: v)],
            ),
            // Invisible dataset fixes the 0..100 scale.
            RadarDataSet(
              fillColor: Colors.transparent,
              borderColor: Colors.transparent,
              entryRadius: 0,
              borderWidth: 0,
              dataEntries: [for (var i = 0; i < 4; i++) const RadarEntry(value: 100)],
            ),
          ],
          radarShape: RadarShape.polygon,
          tickCount: 4,
          ticksTextStyle: const TextStyle(fontSize: 0),
          tickBorderData: BorderSide(color: color.withOpacity(0.3)),
          gridBorderData: BorderSide(color: color.withOpacity(0.3)),
          radarBorderData: BorderSide(color: color.withOpacity(0.4)),
          titleTextStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
          getTitle: (index, angle) => RadarChartTitle(text: labels[index]),
        ),
      ),
    );
  }
}

class _Recommendation extends StatelessWidget {
  const _Recommendation({required this.report});
  final ScoutingReport report;

  @override
  Widget build(BuildContext context) {
    final sorted = report.compatibility.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Best tactical fit',
              style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 4),
          Text(
              '${report.bestPosition.label} (${report.bestPosition.code})',
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 12),
          for (final e in sorted)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(children: [
                SizedBox(width: 44, child: Text(e.key.code)),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                        value: e.value / 100, minHeight: 10),
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(
                    width: 48,
                    child: Text('${e.value.toStringAsFixed(0)}%',
                        textAlign: TextAlign.end)),
              ]),
            ),
        ]),
      ),
    );
  }
}

class _StatEditor extends StatelessWidget {
  const _StatEditor({required this.profile, required this.onChanged});
  final PlayerProfile profile;
  final ValueChanged<PlayerProfile> onChanged;

  Widget _slider(String label, double value, double min, double max,
      String unit, ValueChanged<double> cb) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('$label: ${value.toStringAsFixed(0)} $unit'),
      Slider(value: value.clamp(min, max), min: min, max: max, onChanged: cb),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          _slider('Passing accuracy', profile.passingAccuracy, 0, 100, '%',
              (v) => onChanged(profile.copyWith(passingAccuracy: v))),
          _slider('Shot power', profile.maxShotSpeedKmh, 40, 130, 'km/h',
              (v) => onChanged(profile.copyWith(maxShotSpeedKmh: v))),
          _slider('Sprint speed', profile.sprintSpeedKmh, 15, 36, 'km/h',
              (v) => onChanged(profile.copyWith(sprintSpeedKmh: v))),
          _slider('Weak foot', profile.weakFootScore, 0, 100, '/100',
              (v) => onChanged(profile.copyWith(weakFootScore: v))),
        ]),
      ),
    );
  }
}
