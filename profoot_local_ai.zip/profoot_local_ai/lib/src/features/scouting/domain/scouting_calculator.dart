import '../../profile/data/player_profile_model.dart';

enum FootballPosition { st, cam, cm, lw, rw }

extension FootballPositionX on FootballPosition {
  String get code {
    switch (this) {
      case FootballPosition.st:
        return 'ST';
      case FootballPosition.cam:
        return 'CAM';
      case FootballPosition.cm:
        return 'CM';
      case FootballPosition.lw:
        return 'LW';
      case FootballPosition.rw:
        return 'RW';
    }
  }

  String get label {
    switch (this) {
      case FootballPosition.st:
        return 'Center Forward';
      case FootballPosition.cam:
        return 'Attacking Midfielder';
      case FootballPosition.cm:
        return 'Central Midfielder';
      case FootballPosition.lw:
        return 'Left Winger';
      case FootballPosition.rw:
        return 'Right Winger';
    }
  }
}

/// Normalized 0..100 attributes derived from raw metrics.
class NormalizedStats {
  const NormalizedStats({
    required this.pace,
    required this.shooting,
    required this.passing,
    required this.weakFoot,
  });
  final double pace, shooting, passing, weakFoot;
}

class ScoutingReport {
  const ScoutingReport({
    required this.stats,
    required this.compatibility,
    required this.bestPosition,
    required this.overall,
  });
  final NormalizedStats stats;

  /// Position -> compatibility percent, 0..100.
  final Map<FootballPosition, double> compatibility;
  final FootballPosition bestPosition;
  final int overall;
}

class ScoutingCalculator {
  ScoutingCalculator._();

  // Weights per position: pace, shooting, passing, weak foot (each row sums to 1).
  static const Map<FootballPosition, List<double>> _weights = {
    FootballPosition.st: [0.25, 0.45, 0.10, 0.20],
    FootballPosition.cam: [0.10, 0.25, 0.45, 0.20],
    FootballPosition.cm: [0.10, 0.15, 0.55, 0.20],
    FootballPosition.lw: [0.40, 0.25, 0.15, 0.20],
    FootballPosition.rw: [0.40, 0.25, 0.15, 0.20],
  };

  static double _scale(double v, double lo, double hi) =>
      ((v - lo) / (hi - lo)).clamp(0.0, 1.0) * 100;

  static NormalizedStats normalize(PlayerProfile p) => NormalizedStats(
        pace: _scale(p.sprintSpeedKmh, 15, 36),
        shooting: _scale(p.maxShotSpeedKmh, 40, 130),
        passing: p.passingAccuracy.clamp(0, 100).toDouble(),
        weakFoot: p.weakFootScore.clamp(0, 100).toDouble(),
      );

  static ScoutingReport analyze(PlayerProfile profile) {
    final s = normalize(profile);
    final values = [s.pace, s.shooting, s.passing, s.weakFoot];
    final compat = <FootballPosition, double>{};
    for (final entry in _weights.entries) {
      var total = 0.0;
      for (var i = 0; i < 4; i++) {
        total += values[i] * entry.value[i];
      }
      compat[entry.key] = total;
    }
    final best =
        compat.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
    final overall = (compat[best]! * 0.9 + 8).clamp(1, 99).round();
    return ScoutingReport(
      stats: s,
      compatibility: compat,
      bestPosition: best,
      overall: overall,
    );
  }
}
