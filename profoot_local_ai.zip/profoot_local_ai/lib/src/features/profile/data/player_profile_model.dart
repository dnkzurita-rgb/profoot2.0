import 'package:hive/hive.dart';

/// Player stats persisted locally in Hive (typeId 0).
class PlayerProfile {
  PlayerProfile({
    required this.id,
    required this.name,
    this.passingAccuracy = 60,
    this.maxShotSpeedKmh = 70,
    this.sprintSpeedKmh = 24,
    this.weakFootScore = 40,
    this.positionCompatibility = const {},
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  final String id;
  final String name;

  /// 0..100 percent of passes landing in target.
  final double passingAccuracy;

  /// Best measured shot velocity in km/h.
  final double maxShotSpeedKmh;

  /// Top sprint speed in km/h.
  final double sprintSpeedKmh;

  /// 0..100 weak-foot proficiency.
  final double weakFootScore;

  /// Position code -> compatibility percent (0..100), cached from last scouting run.
  final Map<String, double> positionCompatibility;
  final DateTime updatedAt;

  PlayerProfile copyWith({
    String? name,
    double? passingAccuracy,
    double? maxShotSpeedKmh,
    double? sprintSpeedKmh,
    double? weakFootScore,
    Map<String, double>? positionCompatibility,
  }) =>
      PlayerProfile(
        id: id,
        name: name ?? this.name,
        passingAccuracy: passingAccuracy ?? this.passingAccuracy,
        maxShotSpeedKmh: maxShotSpeedKmh ?? this.maxShotSpeedKmh,
        sprintSpeedKmh: sprintSpeedKmh ?? this.sprintSpeedKmh,
        weakFootScore: weakFootScore ?? this.weakFootScore,
        positionCompatibility:
            positionCompatibility ?? this.positionCompatibility,
        updatedAt: DateTime.now(),
      );
}

class PlayerProfileAdapter extends TypeAdapter<PlayerProfile> {
  @override
  final int typeId = 0;

  @override
  PlayerProfile read(BinaryReader reader) {
    final n = reader.readByte();
    final fields = <int, dynamic>{
      for (var i = 0; i < n; i++) reader.readByte(): reader.read(),
    };
    return PlayerProfile(
      id: fields[0] as String,
      name: fields[1] as String,
      passingAccuracy: fields[2] as double,
      maxShotSpeedKmh: fields[3] as double,
      sprintSpeedKmh: fields[4] as double,
      weakFootScore: fields[5] as double,
      positionCompatibility: (fields[6] as Map)
          .map((k, v) => MapEntry(k as String, (v as num).toDouble())),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(fields[7] as int),
    );
  }

  @override
  void write(BinaryWriter writer, PlayerProfile obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.passingAccuracy)
      ..writeByte(3)
      ..write(obj.maxShotSpeedKmh)
      ..writeByte(4)
      ..write(obj.sprintSpeedKmh)
      ..writeByte(5)
      ..write(obj.weakFootScore)
      ..writeByte(6)
      ..write(obj.positionCompatibility)
      ..writeByte(7)
      ..write(obj.updatedAt.millisecondsSinceEpoch);
  }
}
