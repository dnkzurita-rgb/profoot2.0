import 'dart:math' as math;

import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';
import 'package:vector_math/vector_math.dart' show Vector2;

class PoseIssue {
  const PoseIssue({
    required this.code,
    required this.message,
    required this.joints,
  });
  final String code;
  final String message;
  final Set<PoseLandmarkType> joints;
}

/// Biomechanical checks: knee bend, hip rotation, plant-foot position.
class PoseAnalyzer {
  PoseAnalyzer._();

  static const double _minLikelihood = 0.5;

  static PoseLandmark? _lm(Pose pose, PoseLandmarkType t) {
    final l = pose.landmarks[t];
    if (l == null || l.likelihood < _minLikelihood) return null;
    return l;
  }

  static Vector2 _v(PoseLandmark l) => Vector2(l.x, l.y);

  /// Interior angle at [b] in degrees (a-b-c).
  static double angleDeg(Vector2 a, Vector2 b, Vector2 c) {
    final ba = a - b;
    final bc = c - b;
    final denom = ba.length * bc.length;
    if (denom == 0) return 180;
    final cosv = (ba.dot(bc) / denom).clamp(-1.0, 1.0);
    return math.acos(cosv) * 180 / math.pi;
  }

  static double _lineAngleDeg(Vector2 left, Vector2 right) =>
      math.atan2(right.y - left.y, right.x - left.x) * 180 / math.pi;

  static List<PoseIssue> analyze(Pose pose) {
    final lHip = _lm(pose, PoseLandmarkType.leftHip);
    final rHip = _lm(pose, PoseLandmarkType.rightHip);
    final lKnee = _lm(pose, PoseLandmarkType.leftKnee);
    final rKnee = _lm(pose, PoseLandmarkType.rightKnee);
    final lAnkle = _lm(pose, PoseLandmarkType.leftAnkle);
    final rAnkle = _lm(pose, PoseLandmarkType.rightAnkle);
    final lSh = _lm(pose, PoseLandmarkType.leftShoulder);
    final rSh = _lm(pose, PoseLandmarkType.rightShoulder);
    if (lHip == null ||
        rHip == null ||
        lKnee == null ||
        rKnee == null ||
        lAnkle == null ||
        rAnkle == null) {
      return const [];
    }

    final issues = <PoseIssue>[];

    // The plant leg is the one whose ankle is lower on screen (larger y).
    final leftIsPlant = lAnkle.y >= rAnkle.y;
    final plantHip = leftIsPlant ? lHip : rHip;
    final plantKnee = leftIsPlant ? lKnee : rKnee;
    final plantAnkle = leftIsPlant ? lAnkle : rAnkle;
    final kickAnkle = leftIsPlant ? rAnkle : lAnkle;

    final legLen = (_v(plantHip) - _v(plantKnee)).length +
        (_v(plantKnee) - _v(plantAnkle)).length;
    if (legLen <= 0) return issues;

    final plantJoints = leftIsPlant
        ? {
            PoseLandmarkType.leftHip,
            PoseLandmarkType.leftKnee,
            PoseLandmarkType.leftAnkle
          }
        : {
            PoseLandmarkType.rightHip,
            PoseLandmarkType.rightKnee,
            PoseLandmarkType.rightAnkle
          };

    // 1) Plant knee bend: ideal is a soft 135..165 degrees.
    final kneeAngle =
        angleDeg(_v(plantHip), _v(plantKnee), _v(plantAnkle));
    if (kneeAngle > 172) {
      issues.add(PoseIssue(
        code: 'knee_straight',
        message: 'Bend your plant knee slightly to stay balanced.',
        joints: plantJoints,
      ));
    } else if (kneeAngle < 115) {
      issues.add(PoseIssue(
        code: 'knee_deep',
        message: 'Too much knee bend. Stay tall over the ball.',
        joints: plantJoints,
      ));
    }

    // 2) Plant foot position relative to the hip midpoint.
    final hipMidX = (lHip.x + rHip.x) / 2;
    final offset = (plantAnkle.x - hipMidX).abs() / legLen;
    if (offset > 0.55) {
      issues.add(PoseIssue(
        code: 'plant_wide',
        message: 'Plant foot is too wide. Bring it closer to the ball.',
        joints: {
          if (leftIsPlant) PoseLandmarkType.leftAnkle else PoseLandmarkType.rightAnkle,
        },
      ));
    }

    // 3) Hip rotation, only checked while the kicking leg is lifted.
    final lift = (plantAnkle.y - kickAnkle.y) / legLen;
    if (lSh != null && rSh != null && lift > 0.25) {
      final shoulderAngle = _lineAngleDeg(_v(lSh), _v(rSh));
      final hipAngle = _lineAngleDeg(_v(lHip), _v(rHip));
      var diff = (shoulderAngle - hipAngle).abs();
      if (diff > 180) diff = 360 - diff;
      if (diff < 8) {
        issues.add(const PoseIssue(
          code: 'hip_rotation',
          message: 'Rotate your hips through the ball for more power.',
          joints: {PoseLandmarkType.leftHip, PoseLandmarkType.rightHip},
        ));
      }
    }
    return issues;
  }
}
