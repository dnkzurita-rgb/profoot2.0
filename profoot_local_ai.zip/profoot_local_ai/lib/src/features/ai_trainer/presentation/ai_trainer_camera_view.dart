import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';
import 'package:permission_handler/permission_handler.dart';

import '../bloc/trainer_bloc.dart';
import '../bloc/trainer_event.dart';
import '../bloc/trainer_state.dart';
import 'session_review_screen.dart';

class AiTrainerCameraView extends StatelessWidget {
  const AiTrainerCameraView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => TrainerBloc(),
      child: const _CameraBody(),
    );
  }
}

class _CameraBody extends StatefulWidget {
  const _CameraBody();
  @override
  State<_CameraBody> createState() => _CameraBodyState();
}

class _CameraBodyState extends State<_CameraBody> with WidgetsBindingObserver {
  CameraController? _controller;
  CameraDescription? _camera;
  late final PoseDetector _detector;
  final FlutterTts _tts = FlutterTts();
  final Stopwatch _clock = Stopwatch();
  bool _busy = false;
  bool _permissionDenied = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _detector = PoseDetector(
      options: PoseDetectorOptions(
          mode: PoseDetectionMode.stream, model: PoseDetectionModel.base),
    );
    _setup();
  }

  Future<void> _setup() async {
    final cam = await Permission.camera.request();
    final mic = await Permission.microphone.request();
    if (!cam.isGranted || !mic.isGranted) {
      if (mounted) setState(() => _permissionDenied = true);
      return;
    }
    try {
      await _tts.setLanguage('en-US');
      await _tts.setSpeechRate(0.5);
      final cameras = await availableCameras();
      _camera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );
      final controller = CameraController(
        _camera!,
        ResolutionPreset.medium,
        enableAudio: true,
        imageFormatGroup:
            Platform.isAndroid ? ImageFormatGroup.nv21 : ImageFormatGroup.bgra8888,
      );
      await controller.initialize();
      if (!mounted) return;
      setState(() => _controller = controller);
    } catch (e) {
      if (mounted) setState(() => _error = 'Camera error: $e');
    }
  }

  InputImage? _toInputImage(CameraImage image) {
    final cam = _camera;
    if (cam == null) return null;
    final rotation = InputImageRotationValue.fromRawValue(cam.sensorOrientation);
    final format = InputImageFormatValue.fromRawValue(image.format.raw);
    if (rotation == null || format == null) return null;
    if (Platform.isAndroid && format != InputImageFormat.nv21) return null;
    if (Platform.isIOS && format != InputImageFormat.bgra8888) return null;
    if (image.planes.length != 1) return null;
    final plane = image.planes.first;
    return InputImage.fromBytes(
      bytes: plane.bytes,
      metadata: InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: rotation,
        format: format,
        bytesPerRow: plane.bytesPerRow,
      ),
    );
  }

  Future<void> _onFrame(CameraImage image) async {
    if (_busy) return;
    _busy = true;
    try {
      final input = _toInputImage(image);
      if (input == null) return;
      final poses = await _detector.processImage(input);
      if (!mounted) return;
      context.read<TrainerBloc>().add(PoseFrameReceived(
            pose: poses.isEmpty ? null : poses.first,
            elapsed: _clock.elapsed,
          ));
    } catch (_) {
      // Skip a bad frame; the next one will be processed.
    } finally {
      _busy = false;
    }
  }

  Future<void> _start() async {
    final c = _controller;
    if (c == null || c.value.isStreamingImages) return;
    context.read<TrainerBloc>().add(const TrainerStarted());
    _clock
      ..reset()
      ..start();
    try {
      await c.startVideoRecording();
    } catch (_) {
      // Some devices cannot record while streaming; analysis still runs.
    }
    await c.startImageStream(_onFrame);
    await _tts.speak('Session started. Show me your technique.');
  }

  Future<void> _stop() async {
    final c = _controller;
    if (c == null) return;
    final bloc = context.read<TrainerBloc>();
    final navigator = Navigator.of(context);
    String? videoPath;
    try {
      if (c.value.isStreamingImages) await c.stopImageStream();
      if (c.value.isRecordingVideo) {
        final file = await c.stopVideoRecording();
        videoPath = file.path;
      }
    } catch (_) {}
    _clock.stop();
    bloc.add(const TrainerStopped());
    await _tts.speak('Session complete. Reviewing your clips.');
    if (!mounted) return;
    await navigator.push(MaterialPageRoute(
      builder: (_) => SessionReviewScreen(
        videoPath: videoPath,
        errors: bloc.state.errors,
      ),
    ));
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.inactive && c.value.isStreamingImages) {
      c.stopImageStream();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    _detector.close();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_permissionDenied) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Camera and microphone access are required.'),
          const SizedBox(height: 12),
          FilledButton(
              onPressed: openAppSettings, child: const Text('Open settings')),
        ]),
      );
    }
    if (_error != null) return Center(child: Text(_error!));
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    }

    return BlocConsumer<TrainerBloc, TrainerState>(
      listenWhen: (a, b) => a.speakSeq != b.speakSeq,
      listener: (context, state) {
        final msg = state.spokenMessage;
        if (msg != null) _tts.speak(msg);
      },
      builder: (context, state) {
        final rotation =
            InputImageRotationValue.fromRawValue(_camera!.sensorOrientation) ??
                InputImageRotation.rotation90deg;
        final preview = controller.value.previewSize!;
        final rotated = rotation == InputImageRotation.rotation90deg ||
            rotation == InputImageRotation.rotation270deg;
        final imageSize = rotated
            ? Size(preview.height, preview.width)
            : Size(preview.width, preview.height);
        final running = state.status == TrainerStatus.running;

        return Stack(fit: StackFit.expand, children: [
          const ColoredBox(color: Colors.black),
          Center(
            child: AspectRatio(
              aspectRatio: imageSize.width / imageSize.height,
              child: Stack(fit: StackFit.expand, children: [
                CameraPreview(controller),
                if (state.pose != null)
                  CustomPaint(
                    painter: SkeletonPainter(
                      pose: state.pose!,
                      imageSize: imageSize,
                      flagged: {for (final i in state.issues) ...i.joints},
                    ),
                  ),
              ]),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            top: 48,
            child: _CoachBubble(
              text: running
                  ? (state.issues.isEmpty
                      ? 'Looking good. Keep going!'
                      : state.issues.first.message)
                  : 'AI Coach ready. Tap start and set your phone down.',
              warning: running && state.issues.isNotEmpty,
            ),
          ),
          Positioned(
            bottom: 32,
            left: 0,
            right: 0,
            child: Center(
              child: FloatingActionButton.extended(
                backgroundColor: running ? Colors.red : Colors.greenAccent[700],
                onPressed: running ? _stop : _start,
                icon: Icon(running ? Icons.stop : Icons.play_arrow),
                label: Text(running ? 'Finish session' : 'Start session'),
              ),
            ),
          ),
        ]);
      },
    );
  }
}

class _CoachBubble extends StatelessWidget {
  const _CoachBubble({required this.text, required this.warning});
  final String text;
  final bool warning;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: (warning ? Colors.red[900] : Colors.black)!.withOpacity(0.75),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(children: [
        const CircleAvatar(
            backgroundColor: Colors.greenAccent,
            child: Icon(Icons.sports_soccer, color: Colors.black)),
        const SizedBox(width: 12),
        Expanded(
            child: Text(text,
                style: const TextStyle(color: Colors.white, fontSize: 15))),
      ]),
    );
  }
}

/// Draws the skeleton; flagged joints are highlighted red.
class SkeletonPainter extends CustomPainter {
  SkeletonPainter({
    required this.pose,
    required this.imageSize,
    required this.flagged,
  });
  final Pose pose;
  final Size imageSize;
  final Set<PoseLandmarkType> flagged;

  static const List<List<PoseLandmarkType>> _bones = [
    [PoseLandmarkType.leftShoulder, PoseLandmarkType.rightShoulder],
    [PoseLandmarkType.leftShoulder, PoseLandmarkType.leftHip],
    [PoseLandmarkType.rightShoulder, PoseLandmarkType.rightHip],
    [PoseLandmarkType.leftHip, PoseLandmarkType.rightHip],
    [PoseLandmarkType.leftShoulder, PoseLandmarkType.leftElbow],
    [PoseLandmarkType.leftElbow, PoseLandmarkType.leftWrist],
    [PoseLandmarkType.rightShoulder, PoseLandmarkType.rightElbow],
    [PoseLandmarkType.rightElbow, PoseLandmarkType.rightWrist],
    [PoseLandmarkType.leftHip, PoseLandmarkType.leftKnee],
    [PoseLandmarkType.leftKnee, PoseLandmarkType.leftAnkle],
    [PoseLandmarkType.rightHip, PoseLandmarkType.rightKnee],
    [PoseLandmarkType.rightKnee, PoseLandmarkType.rightAnkle],
    [PoseLandmarkType.leftAnkle, PoseLandmarkType.leftHeel],
    [PoseLandmarkType.leftHeel, PoseLandmarkType.leftFootIndex],
    [PoseLandmarkType.rightAnkle, PoseLandmarkType.rightHeel],
    [PoseLandmarkType.rightHeel, PoseLandmarkType.rightFootIndex],
  ];

  Offset _map(PoseLandmark l, Size size) => Offset(
        l.x * size.width / imageSize.width,
        l.y * size.height / imageSize.height,
      );

  @override
  void paint(Canvas canvas, Size size) {
    final bone = Paint()
      ..color = Colors.greenAccent
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    final bad = Paint()
      ..color = Colors.redAccent
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round;

    for (final pair in _bones) {
      final a = pose.landmarks[pair[0]];
      final b = pose.landmarks[pair[1]];
      if (a == null || b == null) continue;
      if (a.likelihood < 0.5 || b.likelihood < 0.5) continue;
      final isBad = flagged.contains(pair[0]) && flagged.contains(pair[1]);
      canvas.drawLine(_map(a, size), _map(b, size), isBad ? bad : bone);
    }
    for (final entry in pose.landmarks.entries) {
      if (entry.value.likelihood < 0.5) continue;
      canvas.drawCircle(
        _map(entry.value, size),
        flagged.contains(entry.key) ? 8 : 5,
        flagged.contains(entry.key) ? bad : (Paint()..color = Colors.white),
      );
    }
  }

  @override
  bool shouldRepaint(covariant SkeletonPainter old) =>
      old.pose != pose || old.flagged != flagged;
}
