import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../bloc/trainer_state.dart';

/// Post-workout review: plays the local session video and jumps to each
/// logged error as a short clip (2s before to 3s after the marker).
class SessionReviewScreen extends StatefulWidget {
  const SessionReviewScreen({
    super.key,
    required this.videoPath,
    required this.errors,
  });
  final String? videoPath;
  final List<ErrorMarker> errors;

  @override
  State<SessionReviewScreen> createState() => _SessionReviewScreenState();
}

class _SessionReviewScreenState extends State<SessionReviewScreen> {
  VideoPlayerController? _video;
  int _selected = -1;
  Duration _clipEnd = Duration.zero;

  @override
  void initState() {
    super.initState();
    final path = widget.videoPath;
    if (path != null && File(path).existsSync()) {
      final c = VideoPlayerController.file(File(path));
      c.initialize().then((_) {
        if (mounted) setState(() {});
      });
      c.addListener(_onTick);
      _video = c;
    }
  }

  void _onTick() {
    final c = _video;
    if (c == null || _selected < 0) return;
    if (c.value.isPlaying && c.value.position >= _clipEnd) {
      c.pause();
    }
    if (mounted) setState(() {});
  }

  Future<void> _playClip(int index) async {
    final c = _video;
    if (c == null || !c.value.isInitialized) return;
    final at = widget.errors[index].at;
    var start = at - const Duration(seconds: 2);
    if (start < Duration.zero) start = Duration.zero;
    _clipEnd = at + const Duration(seconds: 3);
    setState(() => _selected = index);
    await c.seekTo(start);
    await c.play();
  }

  @override
  void dispose() {
    _video?.removeListener(_onTick);
    _video?.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final video = _video;
    final ready = video != null && video.value.isInitialized;
    return Scaffold(
      appBar: AppBar(title: const Text('Session Review')),
      body: Column(children: [
        AspectRatio(
          aspectRatio: ready ? video.value.aspectRatio : 16 / 9,
          child: ready
              ? Stack(fit: StackFit.expand, children: [
                  VideoPlayer(video),
                  if (_selected >= 0)
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        width: double.infinity,
                        color: Colors.black54,
                        padding: const EdgeInsets.all(8),
                        child: Text(widget.errors[_selected].note,
                            style: const TextStyle(color: Colors.white)),
                      ),
                    ),
                ])
              : const ColoredBox(
                  color: Colors.black12,
                  child: Center(child: Text('No video available'))),
        ),
        Expanded(
          child: widget.errors.isEmpty
              ? const Center(child: Text('No technique errors detected. Great work!'))
              : ListView.separated(
                  itemCount: widget.errors.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final e = widget.errors[i];
                    return ListTile(
                      selected: i == _selected,
                      leading: const Icon(Icons.warning_amber_rounded,
                          color: Colors.redAccent),
                      title: Text(e.note),
                      subtitle: Text('at ${_fmt(e.at)}'),
                      trailing: const Icon(Icons.play_circle_outline),
                      onTap: ready ? () => _playClip(i) : null,
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
