import 'package:equatable/equatable.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

sealed class TrainerEvent extends Equatable {
  const TrainerEvent();
  @override
  List<Object?> get props => [];
}

class TrainerStarted extends TrainerEvent {
  const TrainerStarted();
}

class PoseFrameReceived extends TrainerEvent {
  const PoseFrameReceived({required this.pose, required this.elapsed});
  final Pose? pose;
  final Duration elapsed;
  @override
  List<Object?> get props => [pose, elapsed];
}

class TrainerStopped extends TrainerEvent {
  const TrainerStopped();
}
