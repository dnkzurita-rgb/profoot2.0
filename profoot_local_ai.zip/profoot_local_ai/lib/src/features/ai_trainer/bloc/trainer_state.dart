import 'package:equatable/equatable.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

import '../domain/pose_analyzer.dart';

enum TrainerStatus { idle, running, finished }

/// A pose error logged at a timestamp in the session video.
class ErrorMarker extends Equatable {
  const ErrorMarker({
    required this.at,
    required this.code,
    required this.note,
    required this.joints,
  });
  final Duration at;
  final String code;
  final String note;
  final Set<PoseLandmarkType> joints;
  @override
  List<Object?> get props => [at, code, note];
}

class TrainerState extends Equatable {
  const TrainerState({
    this.status = TrainerStatus.idle,
    this.pose,
    this.issues = const [],
    this.errors = const [],
    this.speakSeq = 0,
    this.spokenMessage,
  });

  final TrainerStatus status;
  final Pose? pose;
  final List<PoseIssue> issues;
  final List<ErrorMarker> errors;

  /// Incremented each time the coach should speak, so listeners fire once.
  final int speakSeq;
  final String? spokenMessage;

  TrainerState copyWith({
    TrainerStatus? status,
    Pose? pose,
    bool clearPose = false,
    List<PoseIssue>? issues,
    List<ErrorMarker>? errors,
    int? speakSeq,
    String? spokenMessage,
  }) =>
      TrainerState(
        status: status ?? this.status,
        pose: clearPose ? null : (pose ?? this.pose),
        issues: issues ?? this.issues,
        errors: errors ?? this.errors,
        speakSeq: speakSeq ?? this.speakSeq,
        spokenMessage: spokenMessage ?? this.spokenMessage,
      );

  @override
  List<Object?> get props =>
      [status, pose, issues, errors, speakSeq, spokenMessage];
}
