import 'package:flutter_bloc/flutter_bloc.dart';

import '../domain/pose_analyzer.dart';
import 'trainer_event.dart';
import 'trainer_state.dart';

class TrainerBloc extends Bloc<TrainerEvent, TrainerState> {
  TrainerBloc() : super(const TrainerState()) {
    on<TrainerStarted>((event, emit) {
      _lastReported.clear();
      emit(const TrainerState(status: TrainerStatus.running));
    });
    on<PoseFrameReceived>(_onFrame);
    on<TrainerStopped>((event, emit) {
      emit(state.copyWith(status: TrainerStatus.finished, clearPose: true));
    });
  }

  static const Duration _cooldown = Duration(seconds: 5);
  final Map<String, Duration> _lastReported = {};

  void _onFrame(PoseFrameReceived event, Emitter<TrainerState> emit) {
    if (state.status != TrainerStatus.running) return;
    final pose = event.pose;
    if (pose == null) {
      emit(state.copyWith(clearPose: true, issues: const []));
      return;
    }
    final issues = PoseAnalyzer.analyze(pose);

    final newMarkers = <ErrorMarker>[];
    String? toSpeak;
    for (final issue in issues) {
      final last = _lastReported[issue.code];
      if (last == null || event.elapsed - last >= _cooldown) {
        _lastReported[issue.code] = event.elapsed;
        newMarkers.add(ErrorMarker(
          at: event.elapsed,
          code: issue.code,
          note: issue.message,
          joints: issue.joints,
        ));
        toSpeak ??= issue.message;
      }
    }

    emit(state.copyWith(
      pose: pose,
      issues: issues,
      errors: newMarkers.isEmpty ? state.errors : [...state.errors, ...newMarkers],
      speakSeq: toSpeak == null ? state.speakSeq : state.speakSeq + 1,
      spokenMessage: toSpeak ?? state.spokenMessage,
    ));
  }
}
